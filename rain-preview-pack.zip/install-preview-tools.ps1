param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

New-Item -ItemType Directory -Path (Join-Path $RepoRoot "blender_tools") -Force | Out-Null

Copy-Item `
    (Join-Path $Seed "blender_tools\render_previews.py") `
    (Join-Path $RepoRoot "blender_tools\render_previews.py") `
    -Force

Copy-Item `
    (Join-Path $Seed "collect-rain-previews.ps1") `
    (Join-Path $RepoRoot "collect-rain-previews.ps1") `
    -Force

Write-Host ""
Write-Host "Installed Rain preview tools:"
Write-Host "  blender_tools\render_previews.py"
Write-Host "  collect-rain-previews.ps1"
Write-Host ""
Write-Host "Next:"
Write-Host "  cd $RepoRoot"
Write-Host "  powershell -ExecutionPolicy Bypass -File .\collect-rain-previews.ps1"
