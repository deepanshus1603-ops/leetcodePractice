import bpy
import json
import os
import sys
import traceback

DEFAULT_FRAMES = [1, 24, 36, 48, 50, 60, 75, 81, 96]

def parse_args():
    out_dir = None
    frames = list(DEFAULT_FRAMES)

    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            out_dir = os.path.abspath(args[0])
        if len(args) > 1 and args[1].strip():
            frames = [int(x.strip()) for x in args[1].split(",") if x.strip()]

    if not out_dir:
        out_dir = os.path.abspath(bpy.path.abspath("//previews"))

    return out_dir, frames

out_dir, frames = parse_args()
os.makedirs(out_dir, exist_ok=True)

scene = bpy.context.scene

result = {
    "mode": "READ_ONLY_PREVIEW",
    "blend_file": bpy.data.filepath,
    "camera": None,
    "frames_requested": frames,
    "frames_rendered": [],
    "errors": [],
    "render_engine_before": scene.render.engine,
    "resolution_before": [
        scene.render.resolution_x,
        scene.render.resolution_y,
        scene.render.resolution_percentage
    ],
}

if scene.camera is None:
    result["errors"].append("No active scene camera found.")
else:
    result["camera"] = scene.camera.name

# Save temporary runtime settings in memory only.
original_engine = scene.render.engine
original_x = scene.render.resolution_x
original_y = scene.render.resolution_y
original_pct = scene.render.resolution_percentage
original_format = scene.render.image_settings.file_format
original_quality = scene.render.image_settings.quality
original_filepath = scene.render.filepath
original_frame = scene.frame_current

try:
    if scene.camera is None:
        raise RuntimeError("No active camera available for preview rendering.")

    # Fast preview render; does not save the .blend file.
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        pass

    # 960x540 gives enough facial detail while keeping handoff small.
    scene.render.resolution_x = 960
    scene.render.resolution_y = 540
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "JPEG"
    scene.render.image_settings.quality = 90

    for frame in frames:
        scene.frame_set(frame)

        filename = f"frame_{frame:03d}.jpg"
        filepath = os.path.join(out_dir, filename)
        scene.render.filepath = filepath

        try:
            bpy.ops.render.render(write_still=True)
            result["frames_rendered"].append({
                "frame": frame,
                "file": filename,
                "path": filepath
            })
            print(f"RAIN_PREVIEW_FRAME_OK {frame} {filepath}")
        except Exception as exc:
            result["errors"].append(
                f"Frame {frame}: {type(exc).__name__}: {exc}"
            )
            print(f"RAIN_PREVIEW_FRAME_FAILED {frame}: {exc}")

except Exception as exc:
    result["errors"].append(f"{type(exc).__name__}: {exc}")
    result["errors"].append(traceback.format_exc())

finally:
    # Restore runtime settings before Blender exits.
    scene.render.engine = original_engine
    scene.render.resolution_x = original_x
    scene.render.resolution_y = original_y
    scene.render.resolution_percentage = original_pct
    scene.render.image_settings.file_format = original_format
    scene.render.image_settings.quality = original_quality
    scene.render.filepath = original_filepath
    scene.frame_set(original_frame)

metadata = os.path.join(out_dir, "preview_manifest.json")
with open(metadata, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print("")
print("============================================")
print("RAIN_PREVIEW_RENDER_OK" if result["frames_rendered"] else "RAIN_PREVIEW_RENDER_FAILED")
print("============================================")
print("READ ONLY: YES")
print("Camera:", result["camera"])
print("Rendered:", len(result["frames_rendered"]), "/", len(frames))
print("Frames:", ", ".join(str(x["frame"]) for x in result["frames_rendered"]))
print("Output:", out_dir)
print("Errors:", len(result["errors"]))
print("============================================")
print("")
