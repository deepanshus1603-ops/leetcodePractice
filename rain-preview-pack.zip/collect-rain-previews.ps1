param(
    [switch]$Push,
    [string]$RepoRoot = "",
    [string]$Frames = "1,24,36,48,50,60,75,81,96"
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$RenderScript = Join-Path $RepoRoot "blender_tools\render_previews.py"

$Latest = Join-Path $RepoRoot "handoff\latest"
$PreviewDir = Join-Path $Latest "previews"
$PreviewLog = Join-Path $Latest "preview_render_log.txt"

if (-not (Test-Path $AgentBlend)) {
    throw "Missing agent working blend: $AgentBlend"
}
if (-not (Test-Path $RenderScript)) {
    throw "Missing preview renderer: $RenderScript"
}

New-Item -ItemType Directory -Path $PreviewDir -Force | Out-Null
Get-ChildItem $PreviewDir -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) {
    throw "Blender executable was not found."
}

$MasterHashBefore = $null
if (Test-Path $MasterBlend) {
    $MasterHashBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
}
$AgentHashBefore = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN PREVIEW COLLECTOR"
Write-Host "=============================================="
Write-Host "Frames: $Frames"
Write-Host "Blender: $Blender"
Write-Host ""

& $Blender `
    --background `
    $AgentBlend `
    --python $RenderScript `
    -- `
    $PreviewDir `
    $Frames 2>&1 |
    Tee-Object -FilePath $PreviewLog

$ExitCode = $LASTEXITCODE

$MasterHashAfter = $null
if (Test-Path $MasterBlend) {
    $MasterHashAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
}
$AgentHashAfter = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$MasterUnchanged = $true
if ($MasterHashBefore -and $MasterHashAfter) {
    $MasterUnchanged = ($MasterHashBefore -eq $MasterHashAfter)
}
$AgentUnchanged = ($AgentHashBefore -eq $AgentHashAfter)

$ManifestPath = Join-Path $PreviewDir "preview_manifest.json"
if (-not (Test-Path $ManifestPath)) {
    throw "Preview manifest was not created. See $PreviewLog"
}

$Manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
$RenderedCount = @($Manifest.frames_rendered).Count
$RequestedCount = @($Manifest.frames_requested).Count

$Pass = (
    $ExitCode -eq 0 -and
    $RenderedCount -eq $RequestedCount -and
    $MasterUnchanged -and
    $AgentUnchanged
)

$SummaryPath = Join-Path $Latest "preview_report.md"

@"
# Rain Preview Report

- Mode: READ_ONLY_PREVIEW
- Result: $(if ($Pass) {"PASS"} else {"FAIL"})
- Blender exit code: $ExitCode
- Camera: $($Manifest.camera)
- Frames requested: $RequestedCount
- Frames rendered: $RenderedCount
- Master blend unchanged: $MasterUnchanged
- Agent blend unchanged: $AgentUnchanged
- Preview folder: handoff/latest/previews
- Errors: $(@($Manifest.errors).Count)
"@ | Set-Content $SummaryPath -Encoding UTF8

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN PREVIEW RESULT: $(if ($Pass) {'PASS'} else {'FAIL'})"
Write-Host "Camera: $($Manifest.camera)"
Write-Host "Rendered: $RenderedCount/$RequestedCount"
Write-Host "Master unchanged: $MasterUnchanged"
Write-Host "Agent blend unchanged: $AgentUnchanged"
Write-Host "Output: $PreviewDir"
Write-Host "=============================================="

if ($Push) {
    Write-Host ""
    Write-Host "Publishing previews to GitHub..."

    git -C $RepoRoot add handoff/latest/previews handoff/latest/preview_render_log.txt handoff/latest/preview_report.md

    $Staged = git -C $RepoRoot diff --cached --name-only

    if (-not [string]::IsNullOrWhiteSpace($Staged)) {
        $Timestamp = (Get-Date).ToString("s")
        git -C $RepoRoot commit -m "Add Rain preview handoff $Timestamp"
        if ($LASTEXITCODE -ne 0) { throw "git commit failed" }

        git -C $RepoRoot push
        if ($LASTEXITCODE -ne 0) { throw "git push failed" }

        Write-Host "Preview handoff pushed successfully."
    } else {
        Write-Host "No preview changes to push."
    }
}
