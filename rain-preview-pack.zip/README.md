# Rain Preview Handoff

The latest handoff confirms Blender 5.2 layered animation is now read correctly:

- action: `RIG-rainAction.002`
- layered action: `True`
- F-curves: `68`
- required controls found: `16/16`
- controls with keyframes: `7`

The current face controls have no keyframes in this action, while the protected arm controls contain the existing wave animation.

This pack adds READ_ONLY preview rendering.

## GPU laptop

Extract and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-preview-tools.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-rain-previews.ps1
```

Default preview frames:

```text
1, 24, 36, 48, 50, 60, 75, 81, 96
```

The script:
- uses `workspace\agent_working.blend`
- uses the existing active Blender camera
- temporarily renders with Eevee at 960x540 JPEG
- does not save the `.blend`
- verifies both master and agent blend hashes are unchanged
- writes preview images under `handoff/latest/previews`

If it reports PASS, publish:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-rain-previews.ps1 -Push
```

On the work laptop, run the existing `get-rain-handoff.ps1` again and upload the new ZIP to ChatGPT.
