# Rain Agent Bootstrap Pack

This pack is for the GPU / Blender laptop.

## One-time setup on the current laptop

1. Extract this ZIP anywhere.
2. Open PowerShell in the extracted folder.
3. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\bootstrap-repo.ps1
```

The script will:

- use `deepanshus1603-ops/rain-animation-agent`
- clone the repo if necessary
- copy `RAIN_AGENT_MASTER_BOOTSTRAP.md` into the repo
- add `setup-local.ps1`
- create tracked folder placeholders
- create `.gitignore`
- create local ignored workspace folders
- copy the master Rain `.blend` to `workspace\agent_working.blend` if found
- commit and push the bootstrap files to GitHub

It does **not** modify the master Blender file.

## Future laptop

After GitHub contains the bootstrap files:

```powershell
cd "$HOME\Desktop\blender\project4"
gh repo clone deepanshus1603-ops/rain-animation-agent
cd .\rain-animation-agent
powershell -ExecutionPolicy Bypass -File .\setup-local.ps1
```

Then launch an Ollama-connected coding agent (for example OpenCode) from inside the repo and instruct it:

```text
Read RAIN_AGENT_MASTER_BOOTSTRAP.md completely.
Inspect the repository and execute the section "First Job to Complete Now".
Create/run/fix the required files yourself.
Remain in READ_ONLY Blender mode until the bootstrap document allows WRITE_SAFE.
```

Plain `ollama run` is a model chat and does not by itself have filesystem/terminal tools. Use an agent wrapper that can edit files and run commands.
