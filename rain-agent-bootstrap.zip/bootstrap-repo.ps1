param(
    [string]$ProjectRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4"),
    [string]$Repo = "deepanshus1603-ops/rain-animation-agent"
)

$ErrorActionPreference = "Stop"

$SeedDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Join-Path $ProjectRoot "rain-animation-agent"

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN AGENT - ONE TIME REPOSITORY BOOTSTRAP"
Write-Host "=============================================="
Write-Host "Repository   : $Repo"
Write-Host "Project root : $ProjectRoot"
Write-Host "Repo root    : $RepoRoot"
Write-Host ""

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    throw "GitHub CLI (gh) is not installed or not on PATH."
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git is not installed or not on PATH."
}

gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
    throw "GitHub CLI is not authenticated. Run: gh auth login"
}

New-Item -ItemType Directory -Path $ProjectRoot -Force | Out-Null

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    if (Test-Path $RepoRoot) {
        $items = Get-ChildItem $RepoRoot -Force -ErrorAction SilentlyContinue
        if ($items.Count -gt 0) {
            throw "Repo folder exists but is not a Git repository: $RepoRoot"
        }
    }

    Write-Host "Cloning repository..."
    gh repo clone $Repo $RepoRoot
    if ($LASTEXITCODE -ne 0) {
        throw "Repository clone failed."
    }
}
else {
    Write-Host "Existing repository clone found."
}

$MasterSource = Join-Path $SeedDir "RAIN_AGENT_MASTER_BOOTSTRAP.md"
$SetupSource  = Join-Path $SeedDir "setup-local.ps1"

if (-not (Test-Path $MasterSource)) {
    throw "Missing seed file: $MasterSource"
}
if (-not (Test-Path $SetupSource)) {
    throw "Missing seed file: $SetupSource"
}

Copy-Item $MasterSource (Join-Path $RepoRoot "RAIN_AGENT_MASTER_BOOTSTRAP.md") -Force
Copy-Item $SetupSource  (Join-Path $RepoRoot "setup-local.ps1") -Force

$TrackedDirs = @(
    "blender_tools",
    "knowledge",
    "prompts"
)

foreach ($rel in $TrackedDirs) {
    $dir = Join-Path $RepoRoot $rel
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $keep = Join-Path $dir ".gitkeep"
    if (-not (Test-Path $keep)) {
        New-Item -ItemType File -Path $keep -Force | Out-Null
    }
}

$GitIgnore = @'
workspace/
__pycache__/
*.pyc
*.blend
*.blend1
*.blend2
*.log
'@
Set-Content -Path (Join-Path $RepoRoot ".gitignore") -Value $GitIgnore -Encoding UTF8

# Ensure repository-local Git identity exists.
$CurrentName = git -C $RepoRoot config user.name
if ([string]::IsNullOrWhiteSpace($CurrentName)) {
    $Login = gh api user --jq .login
    git -C $RepoRoot config user.name $Login
    git -C $RepoRoot config user.email "$Login@users.noreply.github.com"
}

Write-Host "Running local setup..."
& (Join-Path $RepoRoot "setup-local.ps1") -ProjectRoot $ProjectRoot

Write-Host ""
Write-Host "Staging repository bootstrap files..."
git -C $RepoRoot add `
    RAIN_AGENT_MASTER_BOOTSTRAP.md `
    setup-local.ps1 `
    .gitignore `
    blender_tools/.gitkeep `
    knowledge/.gitkeep `
    prompts/.gitkeep

$Staged = git -C $RepoRoot diff --cached --name-only

if (-not [string]::IsNullOrWhiteSpace($Staged)) {
    git -C $RepoRoot commit -m "Add Rain agent bootstrap and local setup"
    if ($LASTEXITCODE -ne 0) {
        throw "Git commit failed."
    }

    Write-Host "Pushing to GitHub..."
    git -C $RepoRoot push -u origin HEAD
    if ($LASTEXITCODE -ne 0) {
        throw "Git push failed."
    }

    Write-Host ""
    Write-Host "Repository bootstrap pushed successfully."
}
else {
    Write-Host "No repository changes to commit."
}

Write-Host ""
Write-Host "=============================================="
Write-Host "BOOTSTRAP COMPLETE"
Write-Host "=============================================="
Write-Host "Repo: $RepoRoot"
Write-Host ""
Write-Host "For this laptop, local runtime folders are ready."
Write-Host ""
Write-Host "On a NEW laptop in the future:"
Write-Host "  1. gh repo clone $Repo"
Write-Host "  2. cd rain-animation-agent"
Write-Host "  3. powershell -ExecutionPolicy Bypass -File .\setup-local.ps1"
Write-Host ""
Write-Host "Then give RAIN_AGENT_MASTER_BOOTSTRAP.md to your"
Write-Host "Ollama-connected coding agent."
Write-Host "=============================================="
