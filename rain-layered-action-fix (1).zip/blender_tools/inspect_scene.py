import bpy
import json
import os
import sys
import traceback

from bpy_extras.anim_utils import animdata_get_channelbag_for_assigned_slot

RIG_NAME = "RIG-rain"

REQUIRED_CONTROLS = [
    "FK-Upperarm_Parent.R",
    "FK-Upperarm.R",
    "FK-Forearm.R",
    "FK-Hand.R",
    "FK-Upperarm_Parent.L",
    "FK-Upperarm.L",
    "FK-Forearm.L",
    "FK-Hand.L",
    "ACT-Lips_Corner.L",
    "ACT-Lips_Corner.R",
    "ACT-Cheek_Outer.L",
    "ACT-Cheek_Outer.R",
    "ACT-Eyelid_Upper.L",
    "ACT-Eyelid_Upper.R",
    "ACT-Eyelid_Lower.L",
    "ACT-Eyelid_Lower.R",
]

def vec(values):
    return [round(float(v), 6) for v in values]

def get_output_path():
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            return os.path.abspath(args[0])
    return os.path.abspath(bpy.path.abspath("//scene_state.json"))

def get_action(rig):
    ad = getattr(rig, "animation_data", None)
    return getattr(ad, "action", None) if ad else None

def get_channelbag(rig):
    ad = getattr(rig, "animation_data", None)
    if not ad:
        return None
    try:
        return animdata_get_channelbag_for_assigned_slot(ad)
    except Exception:
        return None

def get_fcurves(rig):
    bag = get_channelbag(rig)
    if bag is not None:
        try:
            return list(bag.fcurves)
        except Exception:
            pass

    # Fallback for unusual/legacy files.
    action = get_action(rig)
    if action is not None:
        try:
            return list(action.fcurves)
        except Exception:
            pass

    return []

def keyframes_for_bone(fcurves, bone_name):
    frames = set()
    prefix = f'pose.bones["{bone_name}"]'
    for fc in fcurves:
        try:
            if fc.data_path.startswith(prefix):
                for kp in fc.keyframe_points:
                    frames.add(round(float(kp.co.x), 3))
        except Exception:
            pass
    return sorted(frames)

def slot_summary(rig):
    ad = getattr(rig, "animation_data", None)
    slot = getattr(ad, "action_slot", None) if ad else None
    if slot is None:
        return None
    for attr in ("identifier", "name_display", "name"):
        value = getattr(slot, attr, None)
        if value:
            return str(value)
    return str(slot)

state = {
    "inspection_mode": "READ_ONLY",
    "blender_version": bpy.app.version_string,
    "blend_file": bpy.data.filepath,
    "frame_current": bpy.context.scene.frame_current,
    "frame_start": bpy.context.scene.frame_start,
    "frame_end": bpy.context.scene.frame_end,
    "rig_name": RIG_NAME,
    "rig_found": False,
    "rig_type": None,
    "pose_bone_count": 0,
    "action_name": None,
    "action_is_layered": None,
    "action_slot": None,
    "action_fcurve_count": 0,
    "required_controls_total": len(REQUIRED_CONTROLS),
    "required_controls_found": 0,
    "required_controls_with_keyframes": 0,
    "missing_controls": [],
    "controls": {},
    "errors": [],
}

try:
    rig = bpy.data.objects.get(RIG_NAME)

    if rig is None:
        state["errors"].append(f"Rig '{RIG_NAME}' not found.")
    else:
        state["rig_found"] = True
        state["rig_type"] = rig.type
        state["pose_bone_count"] = len(rig.pose.bones)

        action = get_action(rig)
        if action is not None:
            state["action_name"] = action.name
            state["action_is_layered"] = bool(getattr(action, "is_action_layered", False))

        state["action_slot"] = slot_summary(rig)

        fcurves = get_fcurves(rig)
        state["action_fcurve_count"] = len(fcurves)

        for bone_name in REQUIRED_CONTROLS:
            pb = rig.pose.bones.get(bone_name)

            if pb is None:
                state["missing_controls"].append(bone_name)
                state["controls"][bone_name] = {"exists": False}
                continue

            constraints = []
            for c in pb.constraints:
                item = {
                    "name": c.name,
                    "type": c.type,
                    "mute": bool(c.mute),
                }
                try:
                    item["influence"] = round(float(c.influence), 6)
                except Exception:
                    pass
                constraints.append(item)

            frames = keyframes_for_bone(fcurves, bone_name)
            if frames:
                state["required_controls_with_keyframes"] += 1

            state["controls"][bone_name] = {
                "exists": True,
                "location": vec(pb.location),
                "rotation_mode": pb.rotation_mode,
                "rotation_euler": vec(pb.rotation_euler),
                "rotation_quaternion": vec(pb.rotation_quaternion),
                "scale": vec(pb.scale),
                "constraints": constraints,
                "keyframes": frames,
            }
            state["required_controls_found"] += 1

except Exception as exc:
    state["errors"].append(f"{type(exc).__name__}: {exc}")
    state["errors"].append(traceback.format_exc())

out = get_output_path()
os.makedirs(os.path.dirname(out), exist_ok=True)

with open(out, "w", encoding="utf-8") as f:
    json.dump(state, f, indent=2)

print()
print("============================================")
print("RAIN_BLENDER_INSPECT_OK" if state["rig_found"] else "RAIN_BLENDER_INSPECT_FAILED")
print("============================================")
print("READ ONLY: YES")
print("Rig found:", state["rig_found"])
print("Action:", state["action_name"])
print("Layered action:", state["action_is_layered"])
print("Action slot:", state["action_slot"])
print("F-curves:", state["action_fcurve_count"])
print("Pose bones:", state["pose_bone_count"])
print("Required controls:", f'{state["required_controls_found"]}/{state["required_controls_total"]}')
print("Required controls with keyframes:", state["required_controls_with_keyframes"])
print("Missing controls:", ", ".join(state["missing_controls"]) if state["missing_controls"] else "None")
print("Output:", out)
print("============================================")
print()
