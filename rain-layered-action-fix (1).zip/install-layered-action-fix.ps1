param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $RepoRoot "blender_tools\inspect_scene.py"

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

New-Item -ItemType Directory -Path (Split-Path -Parent $Target) -Force | Out-Null

if (Test-Path $Target) {
    Copy-Item $Target "$Target.bak" -Force
    Write-Host "Backup created: $Target.bak"
}

Copy-Item (Join-Path $Seed "blender_tools\inspect_scene.py") $Target -Force

Write-Host ""
Write-Host "Installed Blender 5.2 layered-action inspector fix."
Write-Host ""
Write-Host "Next:"
Write-Host "  cd $RepoRoot"
Write-Host "  powershell -ExecutionPolicy Bypass -File .\collect-rain-state.ps1"
