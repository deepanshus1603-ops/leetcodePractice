param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $RepoRoot "blender_tools\render_previews.py"

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

if (Test-Path $Target) {
    Copy-Item $Target "$Target.bak" -Force
    Write-Host "Backup created: $Target.bak"
}

Copy-Item `
    (Join-Path $Seed "blender_tools\render_previews.py") `
    $Target `
    -Force

Write-Host ""
Write-Host "Installed Rain preview camera fallback fix."
Write-Host ""
Write-Host "The renderer will now:"
Write-Host "  1. use the active scene camera if available"
Write-Host "  2. otherwise use an existing camera object"
Write-Host "  3. otherwise create a temporary in-memory camera"
Write-Host "  4. add temporary lights only if the scene has no lights"
Write-Host ""
Write-Host "No .blend file is saved."
