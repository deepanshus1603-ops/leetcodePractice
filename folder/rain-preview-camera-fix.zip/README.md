# Rain Preview Camera Fix

The first preview attempt failed because the Blender scene reported:

```text
Camera: None
Rendered: 0 / 9
```

This patch makes preview rendering robust.

Camera selection order:

1. active scene camera
2. any existing camera object
3. automatically-created temporary preview camera

If the scene has no render lights, it also creates temporary three-point lighting.

All fallback camera/light objects exist only in memory during the background Blender process. The script never saves the `.blend` file, and the existing collector still verifies both master and agent `.blend` hashes remain unchanged.

## GPU laptop

Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-preview-camera-fix.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-rain-previews.ps1
```

If PASS:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-rain-previews.ps1 -Push
```

Then use the existing work-laptop handoff script and upload the resulting ZIP to ChatGPT.
