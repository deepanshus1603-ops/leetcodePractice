import bpy
import json
import math
import os
import sys
import traceback
from mathutils import Vector

DEFAULT_FRAMES = [1, 24, 36, 48, 50, 60, 75, 81, 96]

def parse_args():
    out_dir = None
    frames = list(DEFAULT_FRAMES)

    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            out_dir = os.path.abspath(args[0])
        if len(args) > 1 and args[1].strip():
            frames = [int(x.strip()) for x in args[1].split(",") if x.strip()]

    if not out_dir:
        out_dir = os.path.abspath(bpy.path.abspath("//previews"))

    return out_dir, frames

def look_at(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()

def object_world_bounds(obj):
    try:
        return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    except Exception:
        return []

def choose_subject_meshes():
    meshes = [
        o for o in bpy.context.scene.objects
        if o.type == "MESH" and not o.hide_render
    ]

    preferred = [
        o for o in meshes
        if "rain" in o.name.lower()
    ]

    return preferred if preferred else meshes

def scene_bounds(objects):
    points = []
    for obj in objects:
        points.extend(object_world_bounds(obj))

    if not points:
        return Vector((0, 0, 1.0)), Vector((1.0, 1.0, 2.0))

    min_v = Vector((
        min(p.x for p in points),
        min(p.y for p in points),
        min(p.z for p in points),
    ))
    max_v = Vector((
        max(p.x for p in points),
        max(p.y for p in points),
        max(p.z for p in points),
    ))

    center = (min_v + max_v) * 0.5
    size = max_v - min_v
    return center, size

def ensure_camera(scene, result):
    original_scene_camera = scene.camera

    if scene.camera is not None:
        result["camera_source"] = "active_scene_camera"
        result["camera"] = scene.camera.name
        return scene.camera, original_scene_camera, None

    cameras = [o for o in scene.objects if o.type == "CAMERA"]

    if cameras:
        cam = cameras[0]
        scene.camera = cam
        result["camera_source"] = "existing_camera_fallback"
        result["camera"] = cam.name
        return cam, original_scene_camera, None

    # No camera exists at all: create an in-memory temporary camera.
    subject = choose_subject_meshes()
    center, size = scene_bounds(subject)

    height = max(float(size.z), 1.0)
    width = max(float(size.x), 0.5)
    depth = max(float(size.y), 0.5)

    # Character rigs are typically viewed from Blender's front direction
    # (camera on negative Y looking toward +Y).
    target = Vector((center.x, center.y, center.z + height * 0.08))
    distance = max(height * 1.35, width * 1.7, depth * 2.0, 3.0)

    cam_data = bpy.data.cameras.new("RAIN_TEMP_PREVIEW_CAMERA_DATA")
    cam = bpy.data.objects.new("RAIN_TEMP_PREVIEW_CAMERA", cam_data)
    scene.collection.objects.link(cam)

    cam.location = Vector((target.x, target.y - distance, target.z))
    cam_data.lens = 52
    cam_data.sensor_width = 36
    look_at(cam, target)

    scene.camera = cam

    result["camera_source"] = "temporary_auto_camera"
    result["camera"] = cam.name
    result["camera_target"] = [round(float(v), 6) for v in target]
    result["subject_size"] = [round(float(v), 6) for v in size]
    result["camera_distance"] = round(float(distance), 6)

    return cam, original_scene_camera, cam

def ensure_lighting(scene, result):
    existing = [o for o in scene.objects if o.type == "LIGHT" and not o.hide_render]
    if existing:
        result["lighting_source"] = "existing_scene_lights"
        result["light_count"] = len(existing)
        return []

    subject = choose_subject_meshes()
    center, size = scene_bounds(subject)
    height = max(float(size.z), 1.0)
    width = max(float(size.x), 0.5)

    temp_lights = []

    def add_area(name, location, energy, size_value):
        data = bpy.data.lights.new(name + "_DATA", type="AREA")
        data.energy = energy
        data.shape = "DISK"
        data.size = size_value
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        obj.location = Vector(location)
        look_at(obj, center)
        temp_lights.append(obj)

    # Key / fill / rim, all temporary and never saved.
    add_area(
        "RAIN_TEMP_KEY",
        (center.x - width * 1.6, center.y - height * 1.3, center.z + height * 1.1),
        1200,
        max(height * 0.8, 2.0),
    )
    add_area(
        "RAIN_TEMP_FILL",
        (center.x + width * 1.5, center.y - height * 0.8, center.z + height * 0.7),
        700,
        max(height * 0.9, 2.0),
    )
    add_area(
        "RAIN_TEMP_RIM",
        (center.x, center.y + height * 1.1, center.z + height * 1.0),
        900,
        max(height * 0.7, 2.0),
    )

    result["lighting_source"] = "temporary_three_point"
    result["light_count"] = 3
    return temp_lights

out_dir, frames = parse_args()
os.makedirs(out_dir, exist_ok=True)

scene = bpy.context.scene

result = {
    "mode": "READ_ONLY_PREVIEW",
    "blend_file": bpy.data.filepath,
    "camera": None,
    "camera_source": None,
    "lighting_source": None,
    "frames_requested": frames,
    "frames_rendered": [],
    "errors": [],
    "render_engine_before": scene.render.engine,
    "resolution_before": [
        scene.render.resolution_x,
        scene.render.resolution_y,
        scene.render.resolution_percentage,
    ],
}

original_engine = scene.render.engine
original_x = scene.render.resolution_x
original_y = scene.render.resolution_y
original_pct = scene.render.resolution_percentage
original_format = scene.render.image_settings.file_format
original_quality = scene.render.image_settings.quality
original_filepath = scene.render.filepath
original_frame = scene.frame_current
original_scene_camera = scene.camera
original_film_transparent = scene.render.film_transparent

temp_camera = None
temp_lights = []

try:
    camera, original_scene_camera, temp_camera = ensure_camera(scene, result)
    temp_lights = ensure_lighting(scene, result)

    # Fast read-only preview render.
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        pass

    scene.render.resolution_x = 960
    scene.render.resolution_y = 540
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "JPEG"
    scene.render.image_settings.quality = 90
    scene.render.film_transparent = False

    for frame in frames:
        scene.frame_set(frame)

        filename = f"frame_{frame:03d}.jpg"
        filepath = os.path.join(out_dir, filename)
        scene.render.filepath = filepath

        try:
            bpy.ops.render.render(write_still=True)
            result["frames_rendered"].append({
                "frame": frame,
                "file": filename,
                "path": filepath,
            })
            print(f"RAIN_PREVIEW_FRAME_OK {frame} {filepath}")
        except Exception as exc:
            result["errors"].append(
                f"Frame {frame}: {type(exc).__name__}: {exc}"
            )
            print(f"RAIN_PREVIEW_FRAME_FAILED {frame}: {exc}")

except Exception as exc:
    result["errors"].append(f"{type(exc).__name__}: {exc}")
    result["errors"].append(traceback.format_exc())

finally:
    # Restore all scene runtime settings. Nothing is saved to the .blend file.
    scene.render.engine = original_engine
    scene.render.resolution_x = original_x
    scene.render.resolution_y = original_y
    scene.render.resolution_percentage = original_pct
    scene.render.image_settings.file_format = original_format
    scene.render.image_settings.quality = original_quality
    scene.render.filepath = original_filepath
    scene.render.film_transparent = original_film_transparent
    scene.frame_set(original_frame)
    scene.camera = original_scene_camera

metadata = os.path.join(out_dir, "preview_manifest.json")
with open(metadata, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print("")
print("============================================")
print("RAIN_PREVIEW_RENDER_OK" if result["frames_rendered"] else "RAIN_PREVIEW_RENDER_FAILED")
print("============================================")
print("READ ONLY: YES")
print("Camera:", result["camera"])
print("Camera source:", result["camera_source"])
print("Lighting:", result["lighting_source"])
print("Rendered:", len(result["frames_rendered"]), "/", len(frames))
print("Frames:", ", ".join(str(x["frame"]) for x in result["frames_rendered"]))
print("Output:", out_dir)
print("Errors:", len(result["errors"]))
print("============================================")
print("")
