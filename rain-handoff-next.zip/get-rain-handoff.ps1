param(
 [string]$Repo="deepanshus1603-ops/rain-animation-agent",
 [string]$LocalRoot="",
 [string]$OutputDir=""
)
$ErrorActionPreference="Stop"
if (-not $LocalRoot) { $LocalRoot=Join-Path $HOME "rain-animation-agent-handoff" }
if (-not $OutputDir) { $OutputDir=Join-Path $HOME "Downloads" }

if (-not (Test-Path (Join-Path $LocalRoot ".git"))) {
  if (Test-Path $LocalRoot) { Remove-Item $LocalRoot -Recurse -Force }
  gh repo clone $Repo $LocalRoot
  if ($LASTEXITCODE -ne 0) { throw "clone failed" }
} else {
  git -C $LocalRoot pull --ff-only
  if ($LASTEXITCODE -ne 0) { throw "pull failed" }
}

$Latest=Join-Path $LocalRoot "handoff\latest"
if (-not (Test-Path $Latest)) { throw "No handoff/latest yet. Run GPU collector with -Push." }
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$Zip=Join-Path $OutputDir "RAIN_CHATGPT_HANDOFF.zip"
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path (Join-Path $Latest "*") -DestinationPath $Zip -Force
Write-Host "CHATGPT HANDOFF READY:"
Write-Host $Zip
