# Rain Handoff - Next Step

## GPU laptop

Extract this ZIP, open PowerShell in the extracted folder, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-gpu.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-rain-state.ps1
```

If that reports PASS, publish it:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-rain-state.ps1 -Push
```

## Work laptop

Keep `get-rain-handoff.ps1` somewhere convenient and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\get-rain-handoff.ps1
```

It creates:

```text
Downloads\RAIN_CHATGPT_HANDOFF.zip
```

Upload that ZIP to ChatGPT.

No `.blend` file is committed or uploaded.
