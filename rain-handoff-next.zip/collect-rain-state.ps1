param([switch]$Push,[string]$RepoRoot="")
$ErrorActionPreference="Stop"
if ([string]::IsNullOrWhiteSpace($RepoRoot)) { $RepoRoot=Split-Path -Parent $MyInvocation.MyCommand.Path }
$RepoRoot=(Resolve-Path $RepoRoot).Path
$ProjectRoot=Split-Path -Parent $RepoRoot
$MasterBlend=Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend=Join-Path $RepoRoot "workspace\agent_working.blend"
$InspectScript=Join-Path $RepoRoot "blender_tools\inspect_scene.py"
$Latest=Join-Path $RepoRoot "handoff\latest"
$SceneState=Join-Path $Latest "scene_state.json"
$BlenderLog=Join-Path $Latest "blender_log.txt"
$Report=Join-Path $Latest "execution_report.md"
$Manifest=Join-Path $Latest "handoff_manifest.json"
$GitStatus=Join-Path $Latest "git_status.txt"
$GitDiff=Join-Path $Latest "git_diff.txt"

if (-not (Test-Path $InspectScript)) { throw "Missing $InspectScript" }
if (-not (Test-Path $AgentBlend)) {
  if (-not (Test-Path $MasterBlend)) { throw "Missing agent and master blend files." }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $AgentBlend) | Out-Null
  Copy-Item $MasterBlend $AgentBlend -Force
}
New-Item -ItemType Directory -Force -Path $Latest | Out-Null
Get-ChildItem $Latest -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force

$Blender=Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
  Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
if (-not $Blender) { throw "Blender executable not found." }

$MasterHashBefore=$null
if (Test-Path $MasterBlend) { $MasterHashBefore=(Get-FileHash $MasterBlend -Algorithm SHA256).Hash }
$AgentHashBefore=(Get-FileHash $AgentBlend -Algorithm SHA256).Hash

& $Blender --background $AgentBlend --python $InspectScript -- $SceneState 2>&1 | Tee-Object -FilePath $BlenderLog
$ExitCode=$LASTEXITCODE
if (-not (Test-Path $SceneState)) { throw "scene_state.json was not created." }

$State=Get-Content $SceneState -Raw | ConvertFrom-Json
$MasterHashAfter=$null
if (Test-Path $MasterBlend) { $MasterHashAfter=(Get-FileHash $MasterBlend -Algorithm SHA256).Hash }
$AgentHashAfter=(Get-FileHash $AgentBlend -Algorithm SHA256).Hash
$MasterUnchanged=($MasterHashBefore -eq $MasterHashAfter)
$AgentUnchanged=($AgentHashBefore -eq $AgentHashAfter)

git -C $RepoRoot status --short | Set-Content $GitStatus -Encoding UTF8
git -C $RepoRoot diff -- . ':(exclude)handoff/latest' | Set-Content $GitDiff -Encoding UTF8

$Pass=($ExitCode -eq 0 -and $State.rig_found -and $State.required_controls_found -eq $State.required_controls_total -and $MasterUnchanged -and $AgentUnchanged)
$Timestamp=(Get-Date).ToString("s")

@"
# Rain Handoff Report

- Timestamp: $Timestamp
- Mode: READ_ONLY
- Result: $(if ($Pass) {"PASS"} else {"FAIL"})
- Blender exit code: $ExitCode
- Rig found: $($State.rig_found)
- Action: $($State.action_name)
- Pose bone count: $($State.pose_bone_count)
- Required controls found: $($State.required_controls_found)/$($State.required_controls_total)
- Missing controls: $([string]::Join(", ", @($State.missing_controls)))
- Master blend unchanged: $MasterUnchanged
- Agent blend unchanged: $AgentUnchanged
"@ | Set-Content $Report -Encoding UTF8

[ordered]@{
 timestamp=$Timestamp; mode="READ_ONLY"; pass=[bool]$Pass; blender_exit_code=$ExitCode;
 rig_found=[bool]$State.rig_found; action_name=$State.action_name; pose_bone_count=[int]$State.pose_bone_count;
 required_controls_found=[int]$State.required_controls_found; required_controls_total=[int]$State.required_controls_total;
 missing_controls=@($State.missing_controls); master_blend_unchanged=[bool]$MasterUnchanged;
 agent_blend_unchanged=[bool]$AgentUnchanged
} | ConvertTo-Json -Depth 8 | Set-Content $Manifest -Encoding UTF8

Write-Host "RAIN HANDOFF RESULT: $(if ($Pass) {'PASS'} else {'FAIL'})"
Write-Host "Rig found: $($State.rig_found)"
Write-Host "Controls: $($State.required_controls_found)/$($State.required_controls_total)"
Write-Host "Handoff: $Latest"

if ($Push) {
  git -C $RepoRoot add handoff/latest
  $Staged=git -C $RepoRoot diff --cached --name-only
  if ($Staged) {
    git -C $RepoRoot commit -m "Update Rain READ_ONLY handoff $Timestamp"
    if ($LASTEXITCODE -ne 0) { throw "git commit failed" }
    git -C $RepoRoot push
    if ($LASTEXITCODE -ne 0) { throw "git push failed" }
    Write-Host "Handoff pushed to GitHub."
  } else { Write-Host "No new handoff changes to push." }
}
