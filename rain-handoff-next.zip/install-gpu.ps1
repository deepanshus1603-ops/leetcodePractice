param([string]$RepoRoot=(Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent"))
$ErrorActionPreference="Stop"
$Seed=Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path (Join-Path $RepoRoot ".git"))) { throw "Repo not found: $RepoRoot" }
New-Item -ItemType Directory -Force -Path (Join-Path $RepoRoot "blender_tools") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $RepoRoot "handoff\latest") | Out-Null
Copy-Item (Join-Path $Seed "blender_tools\inspect_scene.py") (Join-Path $RepoRoot "blender_tools\inspect_scene.py") -Force
Copy-Item (Join-Path $Seed "collect-rain-state.ps1") (Join-Path $RepoRoot "collect-rain-state.ps1") -Force
Write-Host "Installed GPU collector files."
