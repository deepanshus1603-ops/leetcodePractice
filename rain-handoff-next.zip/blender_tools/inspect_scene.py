import bpy, json, os, sys, traceback

RIG_NAME = "RIG-rain"
REQUIRED_CONTROLS = [
    "FK-Upperarm_Parent.R","FK-Upperarm.R","FK-Forearm.R","FK-Hand.R",
    "FK-Upperarm_Parent.L","FK-Upperarm.L","FK-Forearm.L","FK-Hand.L",
    "ACT-Lips_Corner.L","ACT-Lips_Corner.R","ACT-Cheek_Outer.L","ACT-Cheek_Outer.R",
    "ACT-Eyelid_Upper.L","ACT-Eyelid_Upper.R","ACT-Eyelid_Lower.L","ACT-Eyelid_Lower.R"
]

def vec(v): return [round(float(x), 6) for x in v]

def get_output():
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--")+1:]
        if args: return os.path.abspath(args[0])
    return os.path.abspath(bpy.path.abspath("//scene_state.json"))

def get_action(rig):
    ad = getattr(rig, "animation_data", None)
    return getattr(ad, "action", None) if ad else None

def fcurves(action):
    try: return list(action.fcurves) if action else []
    except Exception: return []

def keyframes(action, bone):
    prefix = f'pose.bones["{bone}"]'
    frames = set()
    for fc in fcurves(action):
        try:
            if fc.data_path.startswith(prefix):
                for kp in fc.keyframe_points:
                    frames.add(round(float(kp.co.x), 3))
        except Exception:
            pass
    return sorted(frames)

state = {
    "inspection_mode":"READ_ONLY",
    "blender_version":bpy.app.version_string,
    "blend_file":bpy.data.filepath,
    "frame_current":bpy.context.scene.frame_current,
    "frame_start":bpy.context.scene.frame_start,
    "frame_end":bpy.context.scene.frame_end,
    "rig_name":RIG_NAME,
    "rig_found":False,
    "rig_type":None,
    "pose_bone_count":0,
    "action_name":None,
    "action_fcurve_count":0,
    "required_controls_total":len(REQUIRED_CONTROLS),
    "required_controls_found":0,
    "missing_controls":[],
    "controls":{},
    "errors":[]
}

try:
    rig = bpy.data.objects.get(RIG_NAME)
    if not rig:
        state["errors"].append(f"Rig '{RIG_NAME}' not found.")
    else:
        state["rig_found"] = True
        state["rig_type"] = rig.type
        state["pose_bone_count"] = len(rig.pose.bones)
        action = get_action(rig)
        state["action_name"] = getattr(action, "name", None) if action else None
        state["action_fcurve_count"] = len(fcurves(action))
        for name in REQUIRED_CONTROLS:
            pb = rig.pose.bones.get(name)
            if not pb:
                state["missing_controls"].append(name)
                state["controls"][name] = {"exists":False}
                continue
            cons = []
            for c in pb.constraints:
                item = {"name":c.name,"type":c.type,"mute":bool(c.mute)}
                try: item["influence"] = round(float(c.influence), 6)
                except Exception: pass
                cons.append(item)
            state["controls"][name] = {
                "exists":True,
                "location":vec(pb.location),
                "rotation_mode":pb.rotation_mode,
                "rotation_euler":vec(pb.rotation_euler),
                "rotation_quaternion":vec(pb.rotation_quaternion),
                "scale":vec(pb.scale),
                "constraints":cons,
                "keyframes":keyframes(action, name)
            }
            state["required_controls_found"] += 1
except Exception as e:
    state["errors"].append(f"{type(e).__name__}: {e}")
    state["errors"].append(traceback.format_exc())

out = get_output()
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w", encoding="utf-8") as f:
    json.dump(state, f, indent=2)

print("RAIN_BLENDER_INSPECT_OK" if state["rig_found"] else "RAIN_BLENDER_INSPECT_FAILED")
print("READ ONLY: YES")
print("Rig found:", state["rig_found"])
print("Action:", state["action_name"])
print("Pose bones:", state["pose_bone_count"])
print("Required controls:", f'{state["required_controls_found"]}/{state["required_controls_total"]}')
print("Output:", out)
